package com.v2ray.ang.ui.main

import android.content.Context
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.enums.AetherPsiphon
import com.v2ray.ang.enums.AetherTor
import com.v2ray.ang.enums.AetherProtocol
import com.v2ray.ang.enums.AetherTransport
import com.v2ray.ang.enums.AetherIpVersion
import com.v2ray.ang.enums.EConfigType
import com.v2ray.ang.handler.AngConfigManager
import com.v2ray.ang.handler.MmkvManager

/**
 * hamid_taneel: the configs the connection methods look for. [addMissing] adds only the ones the user does not have,
 * so pressing it again changes nothing.
 */
object StarterConfigs {

    private class AetherSpec(
        val remarks: String,
        val has: (ProfileItem) -> Boolean,
        val fill: (ProfileItem) -> Unit,
    )

    private class JsonSpec(val remarks: String, val asset: String, val marker: String)

    private val aetherSpecs = listOf(
        AetherSpec(
            "hamid · WARP IPv6",
            { it.aetherProtocol == AetherProtocol.WIREGUARD.type && it.aetherIpVersion == AetherIpVersion.V6.type },
        ) {
            it.aetherProtocol = AetherProtocol.WIREGUARD.type
            it.aetherIpVersion = AetherIpVersion.V6.type
        },
        AetherSpec(
            "hamid · WARP WireGuard",
            { it.aetherProtocol == AetherProtocol.WIREGUARD.type },
        ) {
            it.aetherProtocol = AetherProtocol.WIREGUARD.type
            it.aetherIpVersion = AetherIpVersion.DUAL.type
        },
        AetherSpec(
            "hamid · MASQUE-HTTP/2",
            { it.aetherProtocol == AetherProtocol.MASQUE.type && it.aetherTransport == AetherTransport.HTTP2.type },
        ) {
            it.aetherProtocol = AetherProtocol.MASQUE.type
            it.aetherTransport = AetherTransport.HTTP2.type
        },
        AetherSpec(
            "hamid · WireGuard-over-MASQUE",
            { it.aetherProtocol == AetherProtocol.WG_OVER_MASQUE.type },
        ) {
            it.aetherProtocol = AetherProtocol.WG_OVER_MASQUE.type
            it.aetherTransport = AetherTransport.HTTP2.type
        },
        AetherSpec(
            "hamid · WARP ← Psiphon",
            { it.aetherPsiphon == AetherPsiphon.CHAIN.type },
        ) {
            // A plain MASQUE-HTTP/2 tunnel with Psiphon carried through it, as the channel text advises.
            it.aetherProtocol = AetherProtocol.MASQUE.type
            it.aetherTransport = AetherTransport.HTTP2.type
            it.aetherPsiphon = AetherPsiphon.CHAIN.type
        },
    )

    private val extraSpecs = listOf(
        AetherSpec(
            "hamid · Psiphon تنها",
            { it.aetherPsiphon == AetherPsiphon.ONLY.type },
        ) {
            it.aetherPsiphon = AetherPsiphon.ONLY.type
        },
        AetherSpec(
            "hamid · Tor تنها",
            { it.aetherTor == AetherTor.ONLY.type },
        ) {
            it.aetherTor = AetherTor.ONLY.type
        },
        AetherSpec(
            "hamid · WARP ← Tor",
            { it.aetherTor == AetherTor.CHAIN.type },
        ) {
            // Tor carries TCP only, so the WARP under it is MASQUE over HTTP/2.
            it.aetherProtocol = AetherProtocol.MASQUE.type
            it.aetherTransport = AetherTransport.HTTP2.type
            it.aetherTor = AetherTor.CHAIN.type
        },
        AetherSpec(
            "hamid · MASQUE-HTTP/3",
            { it.aetherProtocol == AetherProtocol.MASQUE.type && it.aetherTransport == AetherTransport.HTTP3.type },
        ) {
            it.aetherProtocol = AetherProtocol.MASQUE.type
            it.aetherTransport = AetherTransport.HTTP3.type
        },
        AetherSpec(
            "hamid · WARP-in-WARP",
            { it.aetherProtocol == AetherProtocol.GOOL.type },
        ) {
            it.aetherProtocol = AetherProtocol.GOOL.type
        },
    )

    private val jsonSpecs = listOf(
        JsonSpec("Serverless-v57-oob", "hamid_serverless_oob.json", "oob"),
        JsonSpec("Serverless-v57-frag", "hamid_serverless_frag.json", "frag"),
    )

    /** Adds what is missing; returns the names of the configs added. */
    fun addMissing(context: Context): List<String> {
        val added = ArrayList<String>()

        for (spec in aetherSpecs + extraSpecs) {
            if (ConnectionPresets.findProfile { it.configType == EConfigType.AETHER && spec.has(it) } != null) continue
            val profile = ProfileItem.create(EConfigType.AETHER)
            profile.remarks = spec.remarks
            // No address or port: the app scans for one when it connects, as the Aether editor allows.
            profile.server = ""
            profile.serverPort = ""
            spec.fill(profile)
            MmkvManager.encodeServerConfig("", profile)
            added.add(spec.remarks)
        }

        for (spec in jsonSpecs) {
            if (ConnectionPresets.findProfile { it.remarks.contains(spec.marker, ignoreCase = true) } != null) continue
            val text = try {
                context.assets.open(spec.asset).bufferedReader().use { it.readText() }
            } catch (e: Exception) {
                continue
            }
            val (count, _) = AngConfigManager.importBatchConfig(text, "", false)
            if (count > 0) added.add(spec.remarks)
        }
        return added
    }
}
