package com.v2ray.ang.ui.main

import android.app.AlertDialog
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.v2ray.ang.AppConfig
import com.v2ray.ang.core.LauncherManager
import com.v2ray.ang.handler.MmkvManager
import com.v2ray.ang.handler.SettingsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Credentials
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.InetSocketAddress
import java.net.Proxy
import java.util.concurrent.TimeUnit

/**
 * hamid_taneel: smart connect. Tries every connection method in turn, measures download and
 * upload speed through the local proxy, then connects with the method that scored best.
 */
class SmartConnect(
    private val activity: ComponentActivity,
    private val isRunning: () -> Boolean,
    private val guid: String?,
) {
    private class Result(val title: String, val down: Double, val up: Double) {
        val score get() = down + up
    }

    private var job: Job? = null
    private var dialog: AlertDialog? = null

    fun start() {
        val methods = ConnectionPresets.presets.filter { it.testable }
        val original = guid?.let { MmkvManager.decodeServerConfig(it) }
        val oldLocalProxy = MmkvManager.decodeSettingsBool(AppConfig.PREF_ENABLE_LOCAL_PROXY, true)

        dialog = AlertDialog.Builder(activity)
            .setTitle("اتصال هوشمند")
            .setMessage("در حال آماده‌سازی…")
            .setCancelable(false)
            .setNegativeButton("لغو") { _, _ -> job?.cancel() }
            .show()

        job = activity.lifecycleScope.launch {
            val results = ArrayList<Result>()
            var best: Int? = null
            try {
                // The speed test goes through the local proxy, so it has to be on while testing.
                MmkvManager.encodeSettings(AppConfig.PREF_ENABLE_LOCAL_PROXY, true)
                methods.forEachIndexed { index, method ->
                    say("روش ${index + 1} از ${methods.size}\n${method.title}\n\nدر حال تست دانلود و آپلود…")
                    if (isRunning()) {
                        LauncherManager.stopService(activity)
                        waitFor(false, 8000)
                    }
                    // Every method starts from the profile as the user had it.
                    if (original != null && guid != null) MmkvManager.encodeServerConfig(guid, original.copy())
                    method.apply(guid)
                    LauncherManager.startService(activity)
                    var down = 0.0
                    var up = 0.0
                    if (waitFor(true, 15000)) {
                        delay(1500)
                        down = withContext(Dispatchers.IO) { measure { download(it) } }
                        up = withContext(Dispatchers.IO) { measure { upload(it) } }
                    }
                    results.add(Result(method.title, down, up))
                    if (best == null || results.last().score > results[best!!].score) best = results.lastIndex
                }
            } finally {
                MmkvManager.encodeSettings(AppConfig.PREF_ENABLE_LOCAL_PROXY, oldLocalProxy)
            }

            if (!isActive) return@launch
            if (isRunning()) {
                LauncherManager.stopService(activity)
                waitFor(false, 8000)
            }
            if (original != null && guid != null) MmkvManager.encodeServerConfig(guid, original.copy())

            val winner = best?.let { results[it] }
            val report = results.joinToString("\n") {
                "%s\n   دانلود %.1f  |  آپلود %.1f Mbps".format(it.title, it.down, it.up)
            }
            if (winner == null || winner.score <= 0.0) {
                dialog?.dismiss()
                AlertDialog.Builder(activity)
                    .setTitle("اتصال هوشمند")
                    .setMessage("هیچ روشی اتصال نداشت.\n\n$report")
                    .setPositiveButton("باشه", null)
                    .show()
                return@launch
            }
            methods[best!!].apply(guid)
            LauncherManager.startService(activity)
            dialog?.dismiss()
            AlertDialog.Builder(activity)
                .setTitle("بهترین روش انتخاب شد")
                .setMessage("${winner.title}\n\n$report")
                .setPositiveButton("باشه", null)
                .show()
        }
    }

    private fun say(text: String) {
        dialog?.setMessage(text)
    }

    private suspend fun waitFor(target: Boolean, timeoutMs: Long): Boolean {
        var waited = 0L
        while (waited < timeoutMs) {
            if (isRunning() == target) return true
            delay(250)
            waited += 250
        }
        return isRunning() == target
    }

    private fun client(): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .proxy(Proxy(Proxy.Type.HTTP, InetSocketAddress("127.0.0.1", SettingsManager.getHttpPort())))
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .callTimeout(12, TimeUnit.SECONDS)
        val user = MmkvManager.decodeSettingsString(AppConfig.PREF_SOCKS_USERNAME)
        val pass = MmkvManager.decodeSettingsString(AppConfig.PREF_SOCKS_PASSWORD)
        if (!user.isNullOrEmpty() && !pass.isNullOrEmpty()) {
            builder.proxyAuthenticator { _, response ->
                response.request.newBuilder().header("Proxy-Authorization", Credentials.basic(user, pass)).build()
            }
        }
        return builder.build()
    }

    /** Runs one measurement; a failed one counts as zero speed. */
    private fun measure(block: (OkHttpClient) -> Double): Double =
        try {
            block(client())
        } catch (e: Exception) {
            0.0
        }

    private fun download(c: OkHttpClient): Double {
        val request = Request.Builder().url("https://speed.cloudflare.com/__down?bytes=4000000").build()
        val start = System.nanoTime()
        var bytes = 0L
        c.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return 0.0
            val stream = response.body.byteStream()
            val buffer = ByteArray(16384)
            while (true) {
                val n = stream.read(buffer)
                if (n < 0) break
                bytes += n
                if (System.nanoTime() - start > 8_000_000_000L) break
            }
        }
        val seconds = (System.nanoTime() - start) / 1e9
        return if (seconds > 0) bytes * 8 / seconds / 1e6 else 0.0
    }

    private fun upload(c: OkHttpClient): Double {
        val size = 1_000_000
        val body = ByteArray(size).toRequestBody("application/octet-stream".toMediaType())
        val request = Request.Builder().url("https://speed.cloudflare.com/__up").post(body).build()
        val start = System.nanoTime()
        c.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return 0.0
        }
        val seconds = (System.nanoTime() - start) / 1e9
        return if (seconds > 0) size * 8 / seconds / 1e6 else 0.0
    }
}
