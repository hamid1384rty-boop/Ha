package com.v2ray.ang.ui.main

import com.v2ray.ang.AppConfig
import com.v2ray.ang.enums.EConfigType
import com.v2ray.ang.handler.MmkvManager

/**
 * hamid_taneel: connection methods shown every time the user taps connect.
 * Each method first resets the global settings it touches to their defaults,
 * then applies its own change, so choosing a method always gives the same result.
 */
object ConnectionPresets {

    class Preset(val title: String, val testable: Boolean = true, val apply: (guid: String?) -> Unit)

    private fun resetGlobals() {
        MmkvManager.encodeSettings(AppConfig.PREF_MUX_ENABLED, false)
        MmkvManager.encodeSettings(AppConfig.PREF_SNIFFING_ENABLED, true)
        MmkvManager.encodeSettings(AppConfig.PREF_LOCAL_DNS_ENABLED, true)
        MmkvManager.encodeSettings(AppConfig.PREF_FAKE_DNS_ENABLED, true)
        MmkvManager.encodeSettings(AppConfig.PREF_IPV6_ENABLED, AppConfig.DEFAULT_IPV6_ENABLED)
        MmkvManager.encodeSettings(AppConfig.PREF_PREFER_IPV6, false)
        MmkvManager.encodeSettings(AppConfig.PREF_VPN_MTU, AppConfig.VPN_MTU.toString())
        MmkvManager.encodeSettings(AppConfig.PREF_REMOTE_DNS, AppConfig.DNS_PROXY)
    }

    /** Edits the selected profile; custom JSON, groups and chains are left alone. */
    private fun editProfile(guid: String?, change: (com.v2ray.ang.dto.entities.ProfileItem) -> Unit) {
        if (guid.isNullOrEmpty()) return
        val profile = MmkvManager.decodeServerConfig(guid) ?: return
        if (profile.configType == EConfigType.CUSTOM ||
            profile.configType == EConfigType.POLICYGROUP ||
            profile.configType == EConfigType.PROXYCHAIN
        ) return
        change(profile)
        MmkvManager.encodeServerConfig(guid, profile)
    }

    const val SMART_TITLE = "۹. اتصال هوشمند (تست و انتخاب بهترین روش)"

    val presets: List<Preset> = listOf(
        Preset("۱. DNS راه دور Cloudflare (1.1.1.1)") {
            resetGlobals()
            MmkvManager.encodeSettings(AppConfig.PREF_REMOTE_DNS, "1.1.1.1")
            MmkvManager.encodeSettings(AppConfig.PREF_FAKE_DNS_ENABLED, false)
        },
        Preset("۲. DNS راه دور Google (DoH)") {
            resetGlobals()
            MmkvManager.encodeSettings(AppConfig.PREF_REMOTE_DNS, AppConfig.DNS_PROXY)
            MmkvManager.encodeSettings(AppConfig.PREF_FAKE_DNS_ENABLED, false)
        },
        Preset("۳. Sniffing روشن + FakeDNS خاموش") {
            resetGlobals()
            MmkvManager.encodeSettings(AppConfig.PREF_SNIFFING_ENABLED, true)
            MmkvManager.encodeSettings(AppConfig.PREF_FAKE_DNS_ENABLED, false)
        },
        Preset("۴. فینگرپرینت unsafe (فقط TLS)") { guid ->
            resetGlobals()
            editProfile(guid) { p ->
                if (p.security == AppConfig.TLS) p.fingerPrint = "unsafe"
            }
        },
        Preset("۵. ALPN مناسب (http/1.1 برای WS و HTTPUpgrade)") { guid ->
            resetGlobals()
            editProfile(guid) { p ->
                p.alpn = if (p.network == "ws" || p.network == "httpupgrade") "http/1.1" else null
            }
        },
        Preset("۶. Mux خاموش") {
            resetGlobals()
            MmkvManager.encodeSettings(AppConfig.PREF_MUX_ENABLED, false)
        },
        Preset("۷. IPv6 خاموش") {
            resetGlobals()
            MmkvManager.encodeSettings(AppConfig.PREF_IPV6_ENABLED, false)
            MmkvManager.encodeSettings(AppConfig.PREF_PREFER_IPV6, false)
        },
        Preset("۸. MTU برابر 1280") {
            resetGlobals()
            MmkvManager.encodeSettings(AppConfig.PREF_VPN_MTU, "1280")
        },
        Preset("اتصال با تنظیمات فعلی (بدون تغییر)", testable = false) { },
    )
}
