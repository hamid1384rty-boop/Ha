package com.v2ray.ang.ui.main

import com.v2ray.ang.AppConfig
import com.v2ray.ang.enums.EConfigType
import com.v2ray.ang.handler.MmkvManager

/**
 * hamid_taneel: connection methods shown every time the user taps connect.
 * Each method first resets the global settings it touches to their defaults,
 * then applies its own change, so choosing a method always gives the same result.
 */
object ConnectionPresets {

    /**
     * [target] finds the profile the method needs when it is not the selected one (null result: the user has none,
     * and [missing] says so). [apply] gets the guid of the profile the method runs on.
     */
    class Preset(
        val title: String,
        val testable: Boolean = true,
        val target: (() -> String?)? = null,
        val missing: String = "",
        val apply: (guid: String?) -> Unit,
    )

    private const val FF_MASK =
        "{\"tcp\":[{\"type\":\"fragment\",\"settings\":{\"packets\":\"tlshello\",\"lengths\":[\"0\",\"104\",\"1\"],\"delays\":[\"0\"],\"maxSplit\":\"0\"}}," +
            "{\"type\":\"fragment\",\"settings\":{\"packets\":\"1-1\",\"lengths\":[\"114\",\"1\"],\"delays\":[\"1\"],\"maxSplit\":\"11\"}}]}"

    private const val SEMI_PYTHON =
        "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256:" +
            "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256:" +
            "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA:TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256:" +
            "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256"

    private const val FRAG_SIMPLE =
        "{\"tcp\":[{\"type\":\"fragment\",\"settings\":{\"packets\":\"1-1\",\"lengths\":[\"1\"],\"delays\":[\"1\"],\"maxSplit\":\"201\"}}]}"

    private const val FRAG_TLS =
        "{\"tcp\":[{\"type\":\"fragment\",\"settings\":{\"packets\":\"tlshello\",\"lengths\":[\"6\",\"98\",\"1\"],\"delays\":[\"0\"],\"maxSplit\":\"0\"}}," +
            "{\"type\":\"fragment\",\"settings\":{\"packets\":\"1-1\",\"lengths\":[\"114\",\"1\"],\"delays\":[\"1\"],\"maxSplit\":\"11\"}}]}"

    private const val MERGE_MASK =
        "{\"tcp\":[{\"type\":\"merge\",\"settings\":{\"times\":100,\"delayMs\":30,\"maxBytes\":16384}}]}"

    // The oob method of the Serverless config: merge, then a 75-byte fragment, dialed with oob.
    private const val OOB_MASK =
        "{\"tcp\":[{\"type\":\"merge\",\"settings\":{\"times\":100,\"delayMs\":30,\"maxBytes\":16384}}," +
            "{\"type\":\"fragment\",\"settings\":{\"packets\":\"1-1\",\"lengths\":[\"75\"],\"delays\":[\"30\"],\"maxSplit\":\"2\"}}]}"

    private const val REAL_FIREFOX =
        "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256:" +
            "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384:" +
            "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA:TLS_RSA_WITH_AES_128_GCM_SHA256:" +
            "TLS_RSA_WITH_AES_256_GCM_SHA384:TLS_RSA_WITH_AES_128_CBC_SHA:TLS_RSA_WITH_AES_256_CBC_SHA"

    private const val CLEAN_IPV4 = "188.114.98.0"
    private const val CLEAN_IPV6 = "2a06:98c1:3101::6812:202f"
    private const val ECH_CONFIG = "cloudflare-ech.com+https://1.1.1.1/dns-query"

    /** The first saved profile that fits [test], the selected one first. */
    internal fun findProfile(test: (com.v2ray.ang.dto.entities.ProfileItem) -> Boolean): String? {
        val all = MmkvManager.decodeAllServerList()
        val selected = MmkvManager.getSelectServer()
        return (listOfNotNull(selected).filter { it in all } + all).firstOrNull { guid ->
            MmkvManager.decodeServerConfig(guid)?.let(test) == true
        }
    }

    private fun isAether(p: com.v2ray.ang.dto.entities.ProfileItem) = p.configType == EConfigType.AETHER

    /** A TLS profile with a name to keep (sni) can have its address replaced without losing the domain. */
    private fun com.v2ray.ang.dto.entities.ProfileItem.canMoveAddress() =
        security == AppConfig.TLS && !sni.isNullOrEmpty()

    private fun resetGlobals() {
        MmkvManager.encodeSettings(AppConfig.PREF_MUX_ENABLED, false)
        MmkvManager.encodeSettings(AppConfig.PREF_SNIFFING_ENABLED, true)
        MmkvManager.encodeSettings(AppConfig.PREF_LOCAL_DNS_ENABLED, true)
        MmkvManager.encodeSettings(AppConfig.PREF_FAKE_DNS_ENABLED, true)
        MmkvManager.encodeSettings(AppConfig.PREF_IPV6_ENABLED, AppConfig.DEFAULT_IPV6_ENABLED)
        MmkvManager.encodeSettings(AppConfig.PREF_PREFER_IPV6, false)
        MmkvManager.encodeSettings(AppConfig.PREF_VPN_MTU, AppConfig.VPN_MTU.toString())
        MmkvManager.encodeSettings(AppConfig.PREF_REMOTE_DNS, AppConfig.DNS_PROXY)
    }

    /** Edits the selected profile; custom JSON, groups and chains are left alone. */
    private fun editProfile(guid: String?, change: (com.v2ray.ang.dto.entities.ProfileItem) -> Unit) {
        if (guid.isNullOrEmpty()) return
        val profile = MmkvManager.decodeServerConfig(guid) ?: return
        if (profile.configType == EConfigType.CUSTOM ||
            profile.configType == EConfigType.POLICYGROUP ||
            profile.configType == EConfigType.PROXYCHAIN
        ) return
        change(profile)
        MmkvManager.encodeServerConfig(guid, profile)
    }

    const val SMART_TITLE = "۲۹. اتصال هوشمند (تست و انتخاب بهترین روش)"

    val presets: List<Preset> = listOf(
        Preset("۱. DNS راه دور Cloudflare (1.1.1.1)") {
            resetGlobals()
            MmkvManager.encodeSettings(AppConfig.PREF_REMOTE_DNS, "1.1.1.1")
            MmkvManager.encodeSettings(AppConfig.PREF_FAKE_DNS_ENABLED, false)
        },
        Preset("۲. DNS راه دور Google (DoH)") {
            resetGlobals()
            MmkvManager.encodeSettings(AppConfig.PREF_REMOTE_DNS, AppConfig.DNS_PROXY)
            MmkvManager.encodeSettings(AppConfig.PREF_FAKE_DNS_ENABLED, false)
        },
        Preset("۳. Sniffing روشن + FakeDNS خاموش") {
            resetGlobals()
            MmkvManager.encodeSettings(AppConfig.PREF_SNIFFING_ENABLED, true)
            MmkvManager.encodeSettings(AppConfig.PREF_FAKE_DNS_ENABLED, false)
        },
        Preset("۴. فینگرپرینت unsafe (فقط TLS)") { guid ->
            resetGlobals()
            editProfile(guid) { p ->
                if (p.security == AppConfig.TLS) p.fingerPrint = "unsafe"
            }
        },
        Preset("۵. ALPN مناسب (http/1.1 برای WS و HTTPUpgrade)") { guid ->
            resetGlobals()
            editProfile(guid) { p ->
                p.alpn = if (p.network == "ws" || p.network == "httpupgrade") "http/1.1" else null
            }
        },
        Preset("۶. Mux خاموش") {
            resetGlobals()
            MmkvManager.encodeSettings(AppConfig.PREF_MUX_ENABLED, false)
        },
        Preset("۷. IPv6 خاموش") {
            resetGlobals()
            MmkvManager.encodeSettings(AppConfig.PREF_IPV6_ENABLED, false)
            MmkvManager.encodeSettings(AppConfig.PREF_PREFER_IPV6, false)
        },
        Preset("۸. MTU برابر 1280") {
            resetGlobals()
            MmkvManager.encodeSettings(AppConfig.PREF_VPN_MTU, "1280")
        },
        Preset("۹. F&F فرگمنت + فینگرپرینت (ایرانسل)") { guid ->
            resetGlobals()
            editProfile(guid) { p ->
                if (p.security == AppConfig.TLS) {
                    p.echConfigList = null
                    p.finalMask = FF_MASK
                    p.cipherSuites = SEMI_PYTHON
                    p.fingerPrint = "unsafe"
                    p.alpn = if (p.network == "ws" || p.network == "httpupgrade") "http/1.1" else "h2,http/1.1"
                    if (p.canMoveAddress()) p.server = CLEAN_IPV4
                }
            }
        },
        Preset("۱۰. CDN/Worker روی IPv6 (همراه اول)") { guid ->
            resetGlobals()
            MmkvManager.encodeSettings(AppConfig.PREF_IPV6_ENABLED, true)
            MmkvManager.encodeSettings(AppConfig.PREF_PREFER_IPV6, true)
            editProfile(guid) { p ->
                if (p.security == AppConfig.TLS) {
                    p.echConfigList = null
                    p.cipherSuites = null
                    p.finalMask = null
                    p.fingerPrint = "chrome"
                    if (p.canMoveAddress()) p.server = CLEAN_IPV6
                }
            }
        },
        Preset(
            "۱۱. WARP روی IPv6 (WireGuard)",
            target = { findProfile { isAether(it) && it.aetherProtocol == "wg" && it.aetherIpVersion == "v6" } },
            missing = "کانفیگ WARP (WireGuard با نوع IPv6) ندارید. دکمه‌ی افزودن کانفیگ بالای منو را بزنید.",
        ) {
            resetGlobals()
            MmkvManager.encodeSettings(AppConfig.PREF_IPV6_ENABLED, true)
            MmkvManager.encodeSettings(AppConfig.PREF_PREFER_IPV6, true)
        },
        Preset(
            "۱۲. MASQUE-HTTP/2",
            target = { findProfile { isAether(it) && it.aetherProtocol == "masque" && it.aetherTransport == "h2" } },
            missing = "کانفیگ MASQUE-HTTP/2 ندارید. دکمه‌ی افزودن کانفیگ بالای منو را بزنید.",
        ) {
            resetGlobals()
        },
        Preset(
            "۱۳. WARP ← Psiphon (رفع تحریم)",
            target = { findProfile { isAether(it) && it.aetherPsiphon == "chain" } },
            missing = "کانفیگ WARP با Psiphon (حالت chain) ندارید. دکمه‌ی افزودن کانفیگ بالای منو را بزنید.",
        ) {
            resetGlobals()
        },
        Preset(
            "۱۴. کانفیگ oob (همراه اول)",
            target = { findProfile { it.remarks.contains("oob", ignoreCase = true) } },
            missing = "کانفیگی با اسم oob ندارید. دکمه‌ی افزودن کانفیگ بالای منو را بزنید.",
        ) {
            resetGlobals()
        },
        // The channel text says cloudflare-ech.com is closed, so this is not part of smart connect's tests.
        Preset("۱۵. ECH (طبق متن بسته شده)", testable = false) { guid ->
            resetGlobals()
            editProfile(guid) { p ->
                if (p.security == AppConfig.TLS) {
                    p.echConfigList = ECH_CONFIG
                    p.fingerPrint = "chrome"
                }
            }
        },
        Preset(
            "۱۶. WireGuard-over-MASQUE (IP خارج از ایران)",
            target = { findProfile { isAether(it) && it.aetherProtocol == "wg-over-masque" } },
            missing = "کانفیگ WireGuard-over-MASQUE ندارید. دکمه‌ی افزودن کانفیگ بالای منو را بزنید.",
        ) {
            resetGlobals()
        },
        Preset(
            "۱۷. WARP ساده (WireGuard، هر نوع IP)",
            target = { findProfile { isAether(it) && it.aetherProtocol == "wg" } },
            missing = "کانفیگ WARP (WireGuard) ندارید. دکمه‌ی افزودن کانفیگ بالای منو را بزنید.",
        ) {
            resetGlobals()
        },
        Preset(
            "۱۸. Serverless فرگمنت (ایرانسل، آزمایشی)",
            target = { findProfile { it.remarks.contains("frag", ignoreCase = true) } },
            missing = "کانفیگ Serverless فرگمنت ندارید. دکمه‌ی افزودن کانفیگ بالای منو را بزنید.",
        ) {
            resetGlobals()
        },
        Preset(
            "۱۹. Psiphon تنها (بدون سرور)",
            target = { findProfile { isAether(it) && it.aetherPsiphon == "only" } },
            missing = "کانفیگ Psiphon تنها ندارید. دکمه‌ی افزودن کانفیگ بالای منو را بزنید.",
        ) {
            resetGlobals()
        },
        Preset(
            "۲۰. Tor تنها (بدون سرور)",
            target = { findProfile { isAether(it) && it.aetherTor == "only" } },
            missing = "کانفیگ Tor تنها ندارید. دکمه‌ی افزودن کانفیگ بالای منو را بزنید.",
        ) {
            resetGlobals()
        },
        Preset(
            "۲۱. WARP ← Tor (بدون سرور)",
            target = { findProfile { isAether(it) && it.aetherTor == "chain" } },
            missing = "کانفیگ WARP با Tor ندارید. دکمه‌ی افزودن کانفیگ بالای منو را بزنید.",
        ) {
            resetGlobals()
        },
        Preset(
            "۲۲. MASQUE-HTTP/3 (WARP، بدون سرور)",
            target = { findProfile { isAether(it) && it.aetherProtocol == "masque" && it.aetherTransport == "h3" } },
            missing = "کانفیگ MASQUE-HTTP/3 ندارید. دکمه‌ی افزودن کانفیگ بالای منو را بزنید.",
        ) {
            resetGlobals()
        },
        Preset(
            "۲۳. WARP-in-WARP / GOOL (بدون سرور)",
            target = { findProfile { isAether(it) && it.aetherProtocol == "gool" } },
            missing = "کانفیگ WARP-in-WARP ندارید. دکمه‌ی افزودن کانفیگ بالای منو را بزنید.",
        ) {
            resetGlobals()
        },
        Preset("۲۴. oob روی کانفیگ خودت (همراه اول)") { guid ->
            resetGlobals()
            editProfile(guid) { p ->
                if (p.security == AppConfig.TLS) {
                    p.finalMask = OOB_MASK
                    p.dialMode = "oob.0,0"
                }
            }
        },
        Preset("۲۵. فرگمنت ساده (بسته‌های ۱ بایتی)") { guid ->
            resetGlobals()
            editProfile(guid) { p ->
                if (p.security == AppConfig.TLS) {
                    p.finalMask = FRAG_SIMPLE
                }
            }
        },
        Preset("۲۶. فرگمنت TLS (۶ - ۹۸ - ۱)") { guid ->
            resetGlobals()
            editProfile(guid) { p ->
                if (p.security == AppConfig.TLS) {
                    p.finalMask = FRAG_TLS
                }
            }
        },
        Preset("۲۷. Merge (ادغام بسته‌ها)") { guid ->
            resetGlobals()
            editProfile(guid) { p ->
                if (p.security == AppConfig.TLS) {
                    p.finalMask = MERGE_MASK
                }
            }
        },
        Preset("۲۸. Firefox (فینگرپرینت و cipherSuites)") { guid ->
            resetGlobals()
            editProfile(guid) { p ->
                if (p.security == AppConfig.TLS) {
                    p.fingerPrint = "firefox"
                    p.cipherSuites = REAL_FIREFOX
                }
            }
        },
        Preset("اتصال با تنظیمات فعلی (بدون تغییر)", testable = false) { },
    )
}
